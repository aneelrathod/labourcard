
<html>


<head>

 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  

<img src="onlinelabour-header.jpg" height="110" width="1220">


<center>
<style>
            .menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>

<button class="btn btn-primary"><font color="white">Home</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourhomepage.php">home</a>

</div></nav>




            <style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color:blue}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Instuction</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/Sakala%20-%20Workflow.pdf">sakala workflow</a>

</div></div></nav>

         

 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Notification</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/cla%20notification%20LD%20267%20LET%202016%20dt_20.09.16.pdf">Online Notification</a>

</div></div></nav>



 
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Downloads</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


        

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Application Status</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourapplicationstatus.php">Click Here For Application status </a>
 <a href="#">Form</a>
</div></div></nav>



          

<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 17px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Payment Verification</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labourpayment.php">Click Here For Payment Verification </a>
 <a href="#">Form</a>
</div></div></nav>



<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 120px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">Online Payment</button>
<div class="submenu-content">
  <a href="http://localhost/myfolder/labouronlinepayment.php">Click Here For Online Payment </a>
 <a href="#">Form</a>
</div></div></nav>


          
<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 150px;
}

.submenu-content a {
 color: black;
 padding: 10px 10px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>
<nav>
<div class="submenu">
<button class="btn btn-primary">View Cirtificate</button>
<div class="submenu-content">
  <a href="https://labouronline.kar.nic.in/Files/FORM-V.pdf">Form-V</a>
 <a href="https://labouronline.kar.nic.in/Files/Form_VI_ISMW.pdf">Form-VI</a>
</div></div></nav>


<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>

<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labourloginform.php"><font color="white">login</font></a>
 </button>




<style>

.menu{
 background-color: #222222;
 color: white;
 padding: 18px;
 font-size: 14px;
 border: none;
}
.submenu {
 position: relative;
 display: inline-block;
}

.submenu-content {
 display: none;
 position: absolute;
 background-color: #f9f9f9;
 min-width: 70px;
}

.submenu-content a {
 color: black;
 padding: 5px 5px;
 text-decoration: none;
 display: block;
}

.submenu-content a:hover {background-color: gray}

.submenu:hover .submenu-content {
 display: block;
}
.menu:hover{background-color: orange;}

nav{
display:inline;
float:none;
}


</style>

<button class="btn btn-primary">

  <a href="http://localhost/myfolder/labournewregister.php"><font color="white">New User Login</font></a></button>
 



          


  
    <font color="red"><marquee>For Labour Card New Registration Please Fill The Below Application 2023(Alredy you have registerd go to login form)</marquee> 
      <body style="background:url(articon.jpg);background-size:100%;background-repeat: no-repeat;">
  
    
  </font></center></head>

<body>
  <table border="1" cellpadding="1" cellspacing="1">
<tr><td><img src="labour1.jpeg" height="200" width="200">
<img src="labour2.jpeg" height="200" width="200">
<img src="labour3.jpeg" height="200" width="200">
<img src="labour4.jpg" height="200" width="200">
<img src="labour1.jpeg" height="200" width="200">
<img src="labour6.jpeg" height="200" width="190"></td></tr>
<tr><td>Labour Department Online Services is an Online Facility for Registration, Issue Of Licences and Renewal and Amendment of Registration and Licences under the various Acts of the State and Central Labour Laws and Rules being Enforced by the Department of Labour, Government Of Karnataka. The Department, as part of its functions, enforces various laws in the State which require citizens to interact with the department as part of adherence to various State and Central Enactments. The purpose of the Portal is to Cover the following functions of the Department.
Issuance of Registration Certificate  Renewal of Registration Certificate
Amendment Of Registration Certificate Issuance of New Licence
Issuance or Renewal of Licence  Amendment of Licence
Submission of Annual Returns by the Employer  Half Yearly Returns by Contractor
Quarterly Returns Monthly Returns</td></tr>
</table>
<center><img src="g20.jpg" height="300" width="400"><br>
  <a href="https://youtu.be/X-GyTX_u-Tw?t=10"><button class="btn btn-warning"><font color="black"><b>Click Here And Wacth The Video</font></button></a>

</body>
</html>












